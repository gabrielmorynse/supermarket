var itens;
var item;
var plataforms;
var keys;
var nivel = 1;
var numeroDeIntensIniciais = 9;
var txtnivel ;
var txtPontos;
var pontos = 0;
var counter = 20;
var txtContador = 0;
var carFundo;
var music;

// Lista de produtos do Supermercado
var produtos = [
	{nome:"arroz",arquivo:"image/arroz.png",descricao:"Arroz"},
	{nome:"banana",arquivo:"image/banana.png",descricao:"Banana"},
	{nome:"feijao", arquivo: "image/feijao.png",descricao:"Feijão"},
	{nome:"leite",arquivo:"image/leite.png",descricao:"Leite"},
	{nome:"melancia",arquivo:"image/melancia.png",descricao:"Melancia"},
	{nome:"torrada", arquivo:"image/torrada.png",descricao:"Torrada"},
	{nome:"abacaxi",arquivo:"image/abacaxi.png",descricao:"Abaxi"},
	{nome:"leite cond",arquivo:"image/leite cond.png",descricao:"Leita Condensado"},
	{nome:"coca",arquivo:"image/coca.png",descricao:"Coca-Cola"},
	{nome:"morango",arquivo:"image/morango.png",descricao:"Morango"},
	{nome:"leite cond",arquivo:"image/leite cond.png",descricao:"Leita Condensado"},
	{nome:"coca",arquivo:"image/coca.png",descricao:"Coca-Cola"},
	{nome:"morango",arquivo:"image/morango.png",descricao:"Morango"}
];

var Game = {


	/*carregar os recurso durante o carregamento do jogo*/
	preload: function() {
		game.load.spritesheet('carrinho','image/carrinho.png',270, 249);
		game.load.image('fundo','image/fundo 3.jpg');
		game.load.image('piso','image/piso.png');
		game.load.image('prate','image/prate.png');
		game.load.image('lista','image/lista.png');
		game.load.image('carFundo','image/carFundo.png');
		game.load.audio('Roberto', 'Music/Roberto.mp3', 'Music/Roberto.mp3');

		var tamanho = produtos.length;
		for (var i = 0;i<tamanho;i++) {
			game.load.image(produtos[i].nome,produtos[i]["arquivo"]);
		}

	},

	/*criar os elementos que vão ser usados */
	create: function(){
		game.stage.backgroundColor = '#0D47A1';
		keys = game.input.keyboard.createCursorKeys();
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.add.sprite(0,0,'fundo');
	
		plataforms = game.add.group();
		plataforms.enableBody = true;

		/* prateleria e piso para os itens*/
		var piso = plataforms.create(0,game.world.height - 64,'piso');
		piso.body.immovable = true;

		var prate = plataforms.create(97, 243, 'prate');
		prate.body.immovable = true;

		var prate = plataforms.create(97, 345, 'prate');
		prate.body.immovable = true;

		var prate = plataforms.create(97, 138, 'prate');
		prate.body.immovable = true;
		/*
		var lista = plataforms.create(200, -20, 'lista');
		lista.body.immovable = true;
		*/
		carFundo = plataforms.create(155, 10, 'carFundo');
		carFundo.body.immovable = true;
		carFundo.x = 90;
		carFundo.y = 500;

		itens = game.add.group();
		itens.enableBody = true;

		game.input.mouse.capture = true;

		txtContador = game.add.text(game.world.centerX, game.world.centerY, 'Tempo: 0', {fontSize:'18px', fill:'#fff'});
		txtPontos = game.add.text(680,10,'Pontos:'+ pontos + 'xp',{fontSize:'18px', fill:'#fff'});
		txtnivel = game.add.text(100,10,'Nível:'+ nivel ,{fontSize:'18px', fill:'#fff'});

    		txtContador.anchor.setTo(0, 10.8);

		for(var i = 0; i <1; i++) {
				
				var carrinho = game.add.sprite(10,game.world.height -50, 'carrinho');
				game.physics.arcade.enable(carrinho);
				carrinho.body.gravity.x = 0;
				carrinho.body.collideWorldBounds = true;

			    for (var i2 = 0;i2<numeroDeIntensIniciais;i2++) {
					var item = itens.create(i*2,0,produtos[i2].nome);
					var y = 50+(100*((i2+1)%3));
					if (i2 < 3) {
						var x = 115;
					} else if (i2 < 6) {
						x = 410;
					} else if (i2 < 9) {
						x = 700;
					}
					item.x = x;
					item.y = y;
					item.body.gravity.y = 200;
					item.body.bounce.y = 0.2;
					item.body.collideWorldBounds = true;
					item.inputEnabled = true;
					item.input.enableDrag(true);
				}

    			game.time.events.loop(Phaser.Timer.SECOND, updateCounter, this);

		}
	},

	/* lógica do jogo a ser verificada, colisão, pulo, etc.*/
	update: function(){
		game.physics.arcade.collide(itens, plataforms);
				
		/*Captura click do mouse */
		game.debug.text("Left Button: " + game.input.activePointer.leftButton.isDown, 300, 132);
    	game.debug.text("Middle Button: " + game.input.activePointer.middleButton.isDown, 300, 196);
    	game.debug.text("Right Button: " + game.input.activePointer.rightButton.isDown, 300, 260);

	},

};

	function updateCounter() {
		counter--;
		txtContador.setText('Tempo:'+ counter);

		if (counter == -1) {
			var pontos = 0;
			for (var i2 = 0;i2<numeroDeIntensIniciais;i2++) {
                if(itens.children[i2].position.y > 400 && itens.children[i2].position.y < 435 && itens.children[i2].position.x >52 && itens.children[i2].position.x < 224){
					 console.log(itens.children[i2].key);
					var valido = 0;
					for (var i = 0;i<itensaDecorar.length;i++) {
						if(itens.children[i2].key == itensaDecorar[i].nome) {
							$("#itensAprovados").append('' +
								'<div class="col-xs-4 bordaBranca" id="itemAprovado'+i+'">' +
								'<h1>'+itensaDecorar[i].nome+'</h1> ' +
								'<img src="'+itensaDecorar[i].arquivo+'">' +
								'<span class="glyphicon glyphicon-ok" style="color:green;" aria-hidden="true"></span>' +
								'</div>');
							valido = 1;
							pontos = pontos+10;
						}
					}
					if (valido == 0) {
						$("#itensAprovados").append('' +
							'<div class="col-xs-4 bordaBranca" id="itemAprovado'+i+'">' +
							'<h1>'+itens.children[i2].key+'</h1> ' +
							'<span class="glyphicon glyphicon-remove" style="color:red;" aria-hidden="true"></span>' +
							'</div>');
					}
				}
			}
			$("#pontos").append(pontos+" px");
			$("#listResultado").slideDown("slow");

			return 0;
		}
	}

	function Pontuacao(){

	}

	function ExibirCarrinho(){

	}
    var game = new Phaser.Game(800, 600, Phaser.CANVAS,"GAME");

	var timercount = 0;
	var timestart  = null;


	



