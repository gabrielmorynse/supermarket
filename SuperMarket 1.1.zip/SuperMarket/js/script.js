var itens;
var item;
var plataforms;
var keys;
var nivel = 1;
var txtnivel ; 
var txtPontos;
var pontos = 0;
var counter = 20;
var txtContador = 0;
var music;
var Game = {


	/*carregar os recurso durante o carregamento do jogo*/
	preload: function() {
		game.load.spritesheet('carrinho','image/carrinho.png',270, 249);
		game.load.image('fundo','image/fundo 2.jpg');
		game.load.image('piso','image/piso.png');
		game.load.image('arroz','image/arroz.png');
		game.load.image('banana','image/banana.png');
		game.load.image('feijao','image/feijao.png');
		game.load.image('leite','image/leite.png');
		game.load.image('melancia','image/melancia.png');
		game.load.image('torrada','image/torrada.png');
		game.load.image('abacaxi','image/abacaxi.png');
		game.load.image('prate','image/prate.png');
		game.load.image('lista','image/lista.png');
		game.load.image('carFundo','image/carFundo.png');
		game.load.image('leite cond','image/leite cond.png');
		game.load.image('coca','image/coca.png');
		game.load.image('morango','image/morango.png');
		game.load.audio('Roberto', 'Music/Roberto.mp3', 'Music/Roberto.mp3');
	},

	/*criar os elementos que vão ser usados */
	create: function(){
		game.stage.backgroundColor = '#0D47A1';
		keys = game.input.keyboard.createCursorKeys();
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.add.sprite(0,0,'fundo');
	
		plataforms = game.add.group();
		plataforms.enableBody = true;

		/* prateleria e piso para os itens*/
		var piso = plataforms.create(0,game.world.height - 64,'piso');
		piso.body.immovable = true;

		var prate = plataforms.create(97, 243, 'prate');
		prate.body.immovable = true;

		var prate = plataforms.create(97, 345, 'prate');
		prate.body.immovable = true;

		var prate = plataforms.create(97, 138, 'prate');
		prate.body.immovable = true;
		/*
		var lista = plataforms.create(200, -20, 'lista');
		lista.body.immovable = true;
		*/
		var carFundo = plataforms.create(155, 10, 'carFundo');
		carFundo.body.immovable = true;
		carFundo.x = 90;
		carFundo.y = 500;

		itens = game.add.group();
		itens.enableBody = true;

		game.input.mouse.capture = true;

		txtContador = game.add.text(game.world.centerX, game.world.centerY, 'Tempo: 0', {fontSize:'18px', fill:'#fff'});
    		txtContador.anchor.setTo(0, 10.8);

		for(var i = 0; i <1; i++){
				
				var carrinho = game.add.sprite(10,game.world.height -50, 'carrinho');
				game.physics.arcade.enable(carrinho);
				carrinho.body.gravity.x = 0;
				carrinho.body.collideWorldBounds = true;

				var item = itens.create(i*2,0,'arroz');
				item.x = 150, 300;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

				var item = itens.create(i*2,0,'banana');
				item.x = 270;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

				var item = itens.create(i*2,0,'feijao');
				item.x = 400;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

				var item = itens.create(i*2,0,'leite');
				item.x = 550;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

				var item = itens.create(i*2,0,'melancia');
				item.x = 670;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);
    			

    			var item = itens.create(i*2,0,'torrada');
				item.x = 680;
				item.y = 100;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);
    			
    			
    			var item = itens.create(i*2,0,'abacaxi');
				item.x = 545;
				item.y = 100;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

    			var item = itens.create(i*2,0,'leite cond');
				item.x = 400;
				item.y = 100;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

    			var item = itens.create(i*2,0,'coca');
				item.x = 275;
				item.y = 100;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);

    			var item = itens.create(i*2,0,'morango');
				item.x = 150;
				item.y = 100;
				item.body.gravity.y = 200;
				item.body.bounce.y = 0.2;
				item.body.collideWorldBounds = true;
				item.inputEnabled = true;
    			item.input.enableDrag(true);


    			txtPontos = game.add.text(680,10,'Pontos:'+ pontos + 'xp',{fontSize:'18px', fill:'#fff'});

    			txtnivel = game.add.text(100,10,'Nível:'+ nivel ,{fontSize:'18px', fill:'#fff'});

    			game.time.events.loop(Phaser.Timer.SECOND, updateCounter, this);

		}
	},

	/* lógica do jogo a ser verificada, colisão, pulo, etc.*/
	update: function(){
		game.physics.arcade.collide(itens, plataforms);
				
		/*Captura click do mouse */
		game.debug.text("Left Button: " + game.input.activePointer.leftButton.isDown, 300, 132);
    	game.debug.text("Middle Button: " + game.input.activePointer.middleButton.isDown, 300, 196);
    	game.debug.text("Right Button: " + game.input.activePointer.rightButton.isDown, 300, 260);

	},

};

	function updateCounter(){

		counter--;

		txtContador.setText('Tempo:'+ counter);

		if (counter == -1){
			brake ; 

		}
	}

	function Pontuacao(){

	}

	function ExibirCarrinho(){

	}
    var game = new Phaser.Game(800, 600, Phaser.CANVAS,"GAME");

	var timercount = 0;
	var timestart  = null;


	



